<template>
  <div class="enrollments">
    <div class="content">
      <el-col :span="8">
        <el-card shadow="always">
          <el-divider>
            <i class="el-icon-mobile-phone"></i>
          </el-divider>
          <el-form ref="selectForm" :model="selectForm" label-width="130px" :rules="rules">
            <el-form-item label="姓名" prop="students.stu_name">
              <el-select v-model="selectForm.students" filterable placeholder="请选择您的姓名">
                <el-option
                  v-for="item in students"
                  :key="item.stu_id"
                  :label="item.stu_name"
                  :value="item.stu_id"
                ></el-option>
              </el-select>
            </el-form-item>
            <el-divider content-position="center">欢迎同学们的加入</el-divider>
            <el-form-item label="学会" prop="courses">
              <el-select v-model="selectForm.courses" filterable placeholder="请选择一个学会">
                <el-option
                  v-for="item in courses"
                  :key="item.acad_id"
                  :label="item.acad_name"
                  :value="item.acad_id"
                ></el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="加入年份" prop="join_year" style="width: 52%;" :label-width="formLabelWidth">
              <el-input v-model.number="selectForm.join_year" placeholder="请输入年龄"></el-input>
            </el-form-item>
            <!--
            <el-form-item label="等级" prop="grade">
              <el-select v-model="selectForm.grade" filterable placeholder="请选择您的成绩等级">
                <el-option
                  v-for="item in grade"
                  :key="item.value"
                  :label="item.grade"
                  :value="item.value"
                ></el-option>
              </el-select>
            </el-form-item>
            -->
            <el-form-item>
              <el-button type="primary" @click="onSubmit">确定了</el-button>
              <el-button @click="resetForm('selectForm')">重填</el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </el-col>
    </div>
  </div>
</template>
<script>
import qs from "qs";
export default {
  name: "enrollments",
  data() {
    return {
      name: "Zhou",
      students: [],
      courses: [],
      
      selectForm: {
        students: "",
        courses: "",
        join_year: 2019,
        //grade: ""
      },
      rules: {
        students: [
          { required: true, message: "请留下您的名字", trigger: "change" }
        ],
        courses: [
          {
            required: true,
            message: "请选择一个学会！",
            trigger: "change"
          }
        ]
      }
    };
  },
  methods: {
    onSubmit() {
      if (this.selectForm.students == "") {
        return this.$message({
          message: "请留下您的名字",
          type: "warning"
        });
      }
      if (this.selectForm.courses == "") {
        return this.$message({
          message: "请选择一个学会！",
          type: "warning"
        });
      }
      /*
      if (this.selectForm.grade === "" ) {
        return this.$message({
          message: "选择您的能力等级",
          type: "warning"
        });
      }
      */
      var strData = {
        acad_id: this.selectForm.courses,
        stu_id: '"' + this.selectForm.students + '"',
        join_year: this.selectForm.join_year, 
      };
      console.log(strData);
      this.axios
        .post("http://192.168.10.1:8080/JoinAcad", qs.stringify(strData))
        .then(result => {
          if (result.status == 200 || result.status == 302) {
            this.$notify({
              id: "",
              title: "添加成功(*￣︶￣)，",
              message: "已经成功加入学会！请在学生页查看",
              position: "top-left",
              type: "success"
            });
            this.getStudentData();
            this.resetForm("selectForm");
          } else {
            this.$message({
              message: "添加失败o(╥﹏╥)o" + err,
              type: "danger"
            });
          }
        })
        .catch(err => {});
    },

    // 重置表单
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },

    // 获取全部学生数据
    getStudentData() {
      this.$http.get("http://192.168.10.1:8080/GetStu").then(result => {
        if (result.status == 200) {
          console.log(result);
          this.students = result.data;
        }
      });
    },

    // 获取全部的课程数据
    getAllcourses() {
      this.axios.get("http://192.168.10.1:8080/GetAcad").then(result => {
        if (result.status == 200) {
          this.courses = result.data;
        }
      });
    }
  },
  created() {
    this.getStudentData();
    this.getAllcourses();
  }
};
</script>

<style lang="less" scoped>
.enrollments {
  background-image: url("/static/images/bgnezha.jpg");
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  min-width: 1000px;
  z-index: -10;
  zoom: 1;
  background-color: rgba(0, 0, 0, 0.5);
  background-repeat: repeat;
  background-size: cover;
  -webkit-background-size: cover;
  -o-background-size: cover;
  background-position: center 0;
  .content {
    display: flex;
    // 调整选课框位置
    margin: 13% 0 0 0;
    justify-content: center;
    overflow: hidden;
  }
}
</style>