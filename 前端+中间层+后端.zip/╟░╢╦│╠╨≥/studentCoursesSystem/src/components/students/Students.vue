<template>
  <div class="students">
    <div class="handle">
      <!-- 查询 -->
      <div class="menu">
        <el-timeline>
          <el-timeline-item placement="top">
            <el-card>
              <h4>学生查询</h4>
              <el-input placeholder="请输入姓名" class="searchName" v-model="searchName">
                <!-- <el-button slot="append" type="primary" icon="el-icon-search">搜索</el-button> -->
              </el-input>
              <el-button type="primary" icon="el-icon-search" round>搜索</el-button>
            </el-card>
          </el-timeline-item>
          <el-timeline-item placement="top">
            <el-card>
              <h4>添加学生</h4>
              <el-form
                :model="ruleForm"
                :rules="rules"
                ref="ruleForm"
                label-width="80px"
                class="studentForm"
              >
                <el-form-item label="学号" prop="stuid">
                  <el-input v-model="ruleForm.stuid" placeholder="请输入学号"></el-input>
                </el-form-item>

                <el-form-item label="姓名" prop="name">
                  <el-input v-model="ruleForm.name" placeholder="请输入姓名"></el-input>
                </el-form-item>

                <!--
                <el-form-item label="入学时间" required>
                  <el-col :span="11">
                    <el-form-item prop="date1">
                      <el-date-picker
                        type="date"
                        placeholder="选择日期"
                        v-model="ruleForm.date1"
                        style="width: 100%;"
                      >></el-date-picker>
                    </el-form-item>
                  </el-col>
                  <el-col class="line" :span="2">-</el-col>
                  <el-col :span="11">
                    <el-form-item prop="date2">
                      <el-time-picker
                        placeholder="选择时间"
                        v-model="ruleForm.date2"
                        style="width: 100%;"
                        format="HH:mm"
                        value-format="HH:mm"
                      ></el-time-picker>
                    </el-form-item>
                  </el-col>
                </el-form-item>
                -->
                <el-form-item label="性别" prop="sex">
                  <el-select v-model="ruleForm.sex" placeholder="请选择学生性别">
                    <el-option label="男" value="男"></el-option>
                    <el-option label="女" value="女"></el-option>
                  </el-select>
                </el-form-item>

                <el-form-item label="年龄" prop="age" style="width: 52%;">
                  <el-input v-model.number="ruleForm.age" placeholder="请输入年龄"></el-input>
                </el-form-item>

                <el-form-item label="学院" prop="deptname">
                  <el-select v-model="ruleForm.deptname" placeholder="请选择学院">
                    <el-option label="通信工程系" value="通信工程系"></el-option>
                    <el-option label="电子工程系" value="电子工程系"></el-option>
                    <el-option label="计算机系" value="计算机系"></el-option>
                  </el-select>
                </el-form-item>

                <el-form-item label="班级" prop="classid">
                  <el-input v-model="ruleForm.classid" placeholder="请输入班级"></el-input>
                </el-form-item>

                <el-form-item label="宿舍楼号" prop="dormid">
                  <el-input v-model.number="ruleForm.dormid" placeholder="请输入宿舍号"></el-input>
                </el-form-item>

                <el-form-item>
                  <el-button type="primary" @click="submitForm('ruleForm')">立即添加</el-button>
                  <el-button @click="resetForm('ruleForm')">重置</el-button>
                </el-form-item>
              </el-form>
            </el-card>
          </el-timeline-item>
          <el-timeline-item placement="top">
            <el-card>
              <el-link :underline="false" style="padding-left:8em" @click="getAllDept">
                <i class="el-icon-view el-icon--right"></i>
                系表检查
              </el-link>
              <el-link :underline="false" style="padding-left:8em" @click="getAllClass">
                <i class="el-icon-view el-icon--right"></i>
                班级修改
              </el-link>
              <!-- <el-button type="primary" icon="el-icon-edit" circle></el-button> -->
              <!-- <h4>Created by @刘俊超</h4> -->
            </el-card>
          </el-timeline-item>
        </el-timeline>
      </div>
    </div>
    <div class="formData">
      <el-table
        v-loading="loading"
        element-loading-text="拼命加载中"
        element-loading-spinner="el-icon-loading"
        :data="studentData.filter(data => !searchName || data.stu_name.toLowerCase().includes(searchName.toLowerCase()))"
        border
        style="width: 100%"
        min-height="650"
        max-height="650"
      >
        <el-table-column type="index" :index="indexMethod"></el-table-column>
        <!--
        <el-table-column
          prop="EnrollmentDate"
          sortable
          label="入学时间"
          width="250"
          :formatter="formatter"
        ></el-table-column>
        -->
        <el-table-column prop="stu_id" label="学号" width="150"></el-table-column>
        <el-table-column prop="class_id" label="班级" width="150"></el-table-column>
        <el-table-column prop="stu_name" label="姓名" width="150"></el-table-column>
        <el-table-column prop="stu_sex" label="性别" width="100"></el-table-column>
        <el-table-column label="学会管理" width="150">
          <template slot-scope="scope">
            <el-tooltip content="查看已参加学会列表" placement="right" effect="light" :hide-after="2000">
              <el-button @click="handleCourses(scope.row)" type="success" size="small">
                已加入
                <strong>{{scope.row.acad.length}}</strong>
                个
              </el-button>
            </el-tooltip>
          </template>
        </el-table-column>
        <el-table-column fixed="right" label="信息管理">
          <template slot-scope="scope">
            <el-button @click="handleClick(scope.row)" type="warning" size="small">修改</el-button>
            <el-tooltip content="删除这位同学？" placement="right" effect="light" :hide-after="2000">
              <el-button
                @click="handleDelete(scope.$index, scope.row)"
                type="danger"
                size="small"
                icon="el-icon-delete"
                circle
                plain
              ></el-button>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table>
      <el-dialog title="学生信息" :visible.sync="dialogFormVisible" class="dialogOne">
        <el-form :model="updateForm" class="content">
          <!--
          <el-form-item label="时间" required :label-width="formLabelWidth">
            <el-col :span="11">
              <el-form-item prop="date1">
                <el-date-picker
                  type="date"
                  placeholder="选择日期"
                  v-model="updateForm.date1"
                  style="width: 100%;"
                >></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col class="line" :span="2">-</el-col>
            <el-col :span="11">
              <el-form-item prop="date2">
                <el-time-picker
                  placeholder="选择时间"
                  v-model="updateForm.date2"
                  style="width: 100%;"
                  format="HH:mm"
                  value-format="HH:mm"
                ></el-time-picker>
              </el-form-item>
            </el-col>
          </el-form-item>
          -->
          <el-form-item label="学号" prop="stuid" :label-width="formLabelWidth">
            <el-input v-model="updateForm.stuid" placeholder="请输入学号"></el-input>
          </el-form-item>

          <el-form-item label="姓名" prop="name" :label-width="formLabelWidth">
            <el-input v-model="updateForm.name" placeholder="请输入姓名"></el-input>
          </el-form-item>

          <el-form-item label="性别" prop="sex" :label-width="formLabelWidth">
            <el-select v-model="updateForm.sex" placeholder="请选择学生性别">
              <el-option label="男" value="男"></el-option>
              <el-option label="女" value="女"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="年龄" prop="age" style="width: 52%;" :label-width="formLabelWidth">
            <el-input v-model.number="updateForm.age" placeholder="请输入年龄"></el-input>
          </el-form-item>

          <el-form-item label="学院" prop="deptname" :label-width="formLabelWidth">
            <el-select v-model="updateForm.deptname" placeholder="请选择学院">
              <el-option label="通信工程系" value="通信工程系"></el-option>
              <el-option label="电子工程系" value="电子工程系"></el-option>
              <el-option label="计算机系" value="计算机系"></el-option>
            </el-select>
          </el-form-item>

          <el-form-item label="班级" prop="classid" :label-width="formLabelWidth">
            <el-input v-model="updateForm.classid" placeholder="请输入班级"></el-input>
          </el-form-item>

          <el-form-item label="宿舍楼号" prop="dormid" :label-width="formLabelWidth">
            <el-input v-model.number="updateForm.dormid" placeholder="请输入宿舍号"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="updateStudent">确 定</el-button>
          <el-button @click="dialogFormVisible = false">取 消</el-button>
        </div>
      </el-dialog>
    </div>
    <!-- 关于进阶版的课程管理 -->
    <el-dialog title="学会表" :visible.sync="dialogTableVisible">
      <el-table :data="gridData">
        <!--<el-table-column type="index" :index="indexMethod"></el-table-column>-->
        <el-table-column property="acad_id" label="学会号" width="150"></el-table-column>
        <el-table-column property="acad_name" label="学会名" width="150"></el-table-column>
        <el-table-column property="acad_pos" label="地址" width="200"></el-table-column>
        <el-table-column property="join_year" label="入会年份" width="200"></el-table-column>
        <!--<el-table-column property="grade" label="成绩等级" width="200"></el-table-column> -->
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-tooltip content="退出这个学会？" placement="right" effect="light" :hide-after="2000">
              <el-button
                @click="deleteCourse(scope.$index,scope.row)"
                type="danger"
                size="small"
                icon="el-icon-delete"
                circle
                plain
              ></el-button>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>

    <el-dialog title="班级列表" :visible.sync="dialogClassVisible">
      <el-table :data="classData">
        <el-table-column property="class_id" label="班级号" width="150"></el-table-column>
        <el-table-column property="major_name" label="专业" width="150"></el-table-column>
        <el-table-column property="class_cap" label="人数" width="150"></el-table-column>

        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-tooltip content="修改这个班级？" placement="right" effect="light" :hide-after="2000">
              <el-button
                @click="setClass(scope.row)"
                size="small"
                icon="el-icon-setting"
                circle
                plain
              ></el-button>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>

    <el-dialog title="修改" :visible.sync="classSetVisible" class="dialogOne">
      <el-form :model="classUpdateForm" class="content">
        <el-form-item label="新班级号" prop="newClassid" :label-width="formLabelWidth">
          <el-input v-model="classUpdateForm.newClassid" placeholder="请输入新班号"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="updateClassSet">确 定</el-button>
        <el-button @click="classSetVisible = false">取 消</el-button>
      </div>
    </el-dialog>

    <el-dialog title="系表" :visible.sync="deptSetVisible" class="dialogOne">
      <el-table :data="deptData">
        <el-table-column property="dept_id" label="系号" width="150"></el-table-column>
        <el-table-column property="dept_name" label="系名" width="150"></el-table-column>
        <el-table-column property="dept_office" label="办公地点" width="150"></el-table-column>
        <el-table-column property="dept_cap" label="人数" width="150"></el-table-column>
      </el-table>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="numCheck">检 查</el-button>
      </div>
    </el-dialog>

    <el-dialog title="修改内容" :visible.sync="tempVisible" class="dialogOne">
      <el-table :data="tempData">
        <el-table-column property="dept_id" label="系号" width="150"></el-table-column>
        <el-table-column property="dept_name" label="系名" width="150"></el-table-column>
        <el-table-column property="dept_cap" label="修改前人数" width="150"></el-table-column>
        <el-table-column property="stu_num" label="真实人数" width="150"></el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
import qs from "qs";
export default {
  name: "student",
  data() {
    return {
      name: "Zhou",
      searchName: "",
      searchStudent: [],
      studentData: [],

      deptData:[],
      tempData:[],

      classData: [],
      classUpdateForm: {
        oldClassid: "",
        newClassid: ""
      },
      classSetVisible: false,

      loading: true,
      delay: parseInt(200),
      // 增加学生 表单项设置
      ruleForm: {
        stuid: "",
        name: "",
        sex: "",
        age: "",
        deptname: "",
        classid: "",
        dormid: ""
      },
      // 修改时学生信息 表单项设置
      updateForm: {
        stuid: "",
        name: "",
        sex: "",
        age: "",
        deptname: "",
        classid: "",
        dormid: "",
        id: "",
        checkName: ""
      },
      // 校验规则
      rules: {
        stuid: [
          { required: true, message: "请输入学生学号", trigger: "change" }
        ],
        name: [
          { required: true, message: "请输入学生姓名", trigger: "change" },
          { min: 2, max: 5, message: "长度在 3 到 5 个字符", trigger: "blur" }
        ],
        sex: [{ required: true, message: "请选择学生性别", trigger: "change" }],
        deptname: [
          { required: true, message: "请选择学生学院", trigger: "change" }
        ],
        age: [
          { required: true, message: "年龄不能为空" },
          { type: "number", message: "年龄必须为数字值" }
        ],
        classid: [
          { required: true, message: "请输入班级号", trigger: "change" }
        ],
        dormid: [
          { required: true, message: "宿舍号不能为空" },
          { type: "number", message: "宿舍号必须为数字值" }
        ]
      },

      dialogFormVisible: false,
      formLabelWidth: "5em",

      //存储当前行的课程数据
      gridData: [],

      dialogTableVisible: false,
      deptSetVisible: false,
      tempVisible: false,
      dialogClassVisible: false
    };
  },
  methods: {
    checkClassName() {
      this.$forceUpdate();
    },
    //numCheck
    getAllDept() {
      this.deptSetVisible = true;
      this.$http.get("http://192.168.10.1:8080/GetDept").then(result => {
        if (result.status == 200) {
          this.deptData = result.data;
          //console.log(this.studentData);
          //this.loading = false;
        }
      });
    },

    numCheck() {
      this.$http.get("http://192.168.10.1:8080/CheckDeptCap").then(result => {
        if (result.status == 200 ) {
          this.tempData = result.data.changed_dept;
          this.deptSetVisible = false;
          this.tempVisible = true;
          //console.log(this.studentData);
          //this.loading = false;
          if(result.data.length==0){alert("人数全部正确！");}
        }
      });
    },

    getAllClass() {
      this.dialogClassVisible = true;
      this.$http.get("http://192.168.10.1:8080/GetClass").then(result => {
        if (result.status == 200) {
          this.classData = result.data;
          //console.log(this.studentData);
          //this.loading = false;
        }
      });
    },

    setClass(row) {
      //console.log(row.class_id);
      this.classUpdateForm.oldClassid = row.class_id;
      this.dialogClassVisible = false;
      this.classSetVisible = true;
    },

    updateClassSet() {
      var strData = {
        old_class_id: '"' + this.classUpdateForm.oldClassid + '"',
        new_class_id: '"' + this.classUpdateForm.newClassid + '"'
      };
      console.log(strData);
      this.axios
        .post("http://192.168.10.1:8080/ChangeClassId", qs.stringify(strData))
        .then(result => {
          if (result.status == 200 || result.status == 302) {
            console.log(result);
            this.$message({
              message: "修改成功(*￣︶￣)，人数为" + result.data.class_cap,
              type: "success"
            });
            //this.gridData.splice(index, 1);
            this.classUpdateForm.newClassid = "";
            dialogClassVisible = true;
            classSetVisible = false;
            this.getAllClass();
            //this.loading = true;
            this.getStudentData();
          }
        })
        .catch(err => {
          /*
          this.$message({
            message: "修改失败o(╥﹏╥)o",
            type: "danger"
          });
          */
        });
    },

    // 实现后台的课程管理
    handleCourses(row) {
      this.dialogTableVisible = true;
      //this.gridName = row.Name;
      this.gridData = [];
      row.acad.forEach(item => {
        var newCourse = {
          acad_id: item.acad_id,
          acad_name: item.acad_name,
          acad_pos: item.acad_pos,
          join_year: item.join_year,
          //grade: item.Grade,
          //coursesName: item.CourseId
        };
        newCourse.stu_id = row.stu_id;
        this.gridData.push(newCourse);
      });
    },

    // 删除对应的课程
    deleteCourse(index, row) {
      console.log(index + " " + row.stu_id + " " + row.acad_id);
      this.$confirm("此操作将退出此学会, 是否继续?", "提示", {
        cancelButtonText: "取消",
        confirmButtonText: "确定",
        type: "warning"
      })
        .then(() => {
          this.axios
            .post(
              'http://192.168.10.1:8080/QuitAcad?stu_id="' +
                row.stu_id +
                '"&acad_id=' +
                row.acad_id
            )
            .then(result => {
              if (result.status == 200 || result.status == 302) {
                this.$message({
                  message: "删除成功(*￣︶￣)，",
                  type: "success"
                });
                this.gridData.splice(index, 1);
                this.getStudentData();
              }
            })
            .catch(err => {
              this.$message({
                message: "删除失败o(╥﹏╥)o",
                type: "danger"
              });
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },

    // 实现查询功能
    findSomeOne(name) {
      if ((name = "")) {
        this.searchStudent = this.studentData;
      }
      this.searchStudent = this.studentData.filter(item => {
        if (item.Name.indexOf(name) != -1) {
          return item;
        }
      });
    },

    // 实现删除功能
    handleDelete(index, row) {
      // console.log(index, row);
      this.$confirm("此操作将删除该同学所有信息, 是否继续?", "提示", {
        cancelButtonText: "取消",
        confirmButtonText: "确定",
        type: "warning"
      })
        .then(() => {
          this.axios
            .get("http://192.168.10.1:8080/DelStu?stu_id=" + row.stu_id)
            .then(result => {
              if (result.status == 200 || result.status == 302) {
                this.$message({
                  message: "删除成功(*￣︶￣)，",
                  type: "success"
                });
                this.getStudentData();
              }
            })
            .catch(err => {
              this.$message({
                message: "删除失败o(╥﹏╥)o",
                type: "danger"
              });
            });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },

    // 实现添加功能
    submitForm(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          // 表单验证成功
          var strData = {
            //Name: this.ruleForm.name,
            //StudentType: parseInt(this.ruleForm.sex),
            //EnrollmentDate: this.sendAddTime(
            //this.ruleForm.date1,
            //this.ruleForm.date2
            //),
            stu_id: '"' + this.ruleForm.stuid + '"',
            stu_name: '"' + this.ruleForm.name + '"',
            stu_sex: '"' + this.ruleForm.sex + '"',
            stu_age: this.ruleForm.age,
            dept_name: '"' + this.ruleForm.deptname + '"',
            class_id: '"' + this.ruleForm.classid + '"',
            dorm_id: this.ruleForm.dormid
          };
          console.log(strData);
          // 改变post的编码格式，适应后台
          this.axios
            .post("http://192.168.10.1:8080/AddStu", qs.stringify(strData))
            .then(result => {
              if (result.status == 200 || result.status == 302) {
                this.$message({
                  message: "添加成功(*￣︶￣)，",
                  type: "success"
                });
                this.getStudentData();
                this.resetForm("ruleForm");
              }
            })
            .catch(err => {
              console.log(err);
              this.$message({
                message: "添加失败o(╥﹏╥)o",
                type: "danger"
              });
            });
        } else {
          this.$message.error("信息填写不完整喔！");
          // console.log("error submit!!");
          return false;
        }
      });
    },
    // 重置表单
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    //为表格添加序号
    indexMethod(index) {
      return index + 1;
    },

    //实现修改功能
    handleClick(row) {
      // 数据回显
      this.dialogFormVisible = true;
      this.updateForm.stuid = row.stu_id;
      this.updateForm.name = row.stu_name;
      // 用于提交修改时的校验，由于name被双向绑定了，这里未来防止 name被恶意清空，派出幕后英雄checkName
      this.updateForm.checkName = row.stu_name;
      //this.updateForm.date1 = this.getDateOne(row.EnrollmentDate);
      //this.updateForm.date2 = this.getDateTwo(row.EnrollmentDate);
      this.updateForm.sex = row.stu_sex;
      this.updateForm.age = row.stu_age;
      this.updateForm.deptname = row.dept_name;
      this.updateForm.classid = row.class_id;
      this.updateForm.dormid = row.dorm_id;
      console.log(row);
    },
    // 提交修改
    updateStudent() {
      this.dialogFormVisible = false;
      var updateData = {
        stu_id: '"' + this.updateForm.stuid + '"',
        stu_name: '"' + this.updateForm.name + '"',
        stu_sex: '"' + this.updateForm.sex + '"',
        stu_age: this.updateForm.age,
        dept_name: '"' + this.updateForm.deptname + '"',
        class_id: '"' + this.updateForm.classid + '"',
        dorm_id: this.updateForm.dormid
      };
      console.log(updateData);
      // 改变post的编码格式，适应后台做修改！
      this.axios
        .post("http://192.168.10.1:8080/EditStu", qs.stringify(updateData))
        .then(result => {
          if (result.status == 200 || result.status == 302) {
            this.$notify({
              id: "",
              title: "修改成功",
              message: "信息已修改完成！请查看",
              type: "success"
            });
            this.getStudentData();
          }
        })
        .catch(err => {
          this.$message({
            message: "添加失败o(╥﹏╥)o",
            type: "danger"
          });
        });
    },

    // 获取全部学生数据
    getStudentData() {
      this.$http.get("http://192.168.10.1:8080/GetStu").then(result => {
        if (result.status == 200) {
          // console.log(result.data);
          //result.data.forEach(item => {
          //item.StudentType == 0
          //? (item.StudentType = "Junior")
          //: (item.StudentType = "Senior");
          //});
          this.studentData = result.data;
          //console.log(this.studentData);
          this.loading = false;
        }
      });
    },

    // 绑定入学日期，格式化时间
    formatter(row, colum) {
      return this.GetTimeByTimeStr(row.EnrollmentDate);
    },
    // 修改时获得对应的日期（date1）和时间(date2)
    getDateOne(time) {
      var timeArr = time.split("T");
      var d = timeArr[0].split("-");
      return new Date(d[0], d[1] - 1, d[2]);
    },
    getDateTwo(time) {
      var timeArr = time.split("T");
      var t = timeArr[1].split(":");
      return t[0] + ":" + t[1];
    },
    // 时间处理函数
    GetTimeByTimeStr(dateString) {
      var timeArr = dateString.split("T");
      var d = timeArr[0].split("-");
      var t = timeArr[1].split(":");
      var newTime =
        d[0] + "年" + d[1] + "月" + d[2] + "日" + " " + t[0] + ":" + t[1];
      // 生成new Date 的月份取值0-11 需要处理
      // var date = new Date(d[0], d[1] - 1, d[2], t[0], t[1], t[2]);
      return newTime;
    },

    // 将新添加的学生入学时间进行格式转换（注：data1是日期 date2是时间）
    sendAddTime(date, date2) {
      var Y = date.getFullYear();
      var M =
        date.getMonth() + 1 < 10
          ? "0" + (date.getMonth() + 1)
          : date.getMonth() + 1;
      var MT = parseInt(M) + 1;
      var D = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
      var addTime = Y + "-" + M + "-" + D + "T" + date2;
      return addTime;
    }
  },
  //页面数据初始化
  // 增加loading
  mounted() {
    this.getStudentData();
  }
};
</script>

<style lang="less" scoped>
.students {
  display: flex;
  height: 42em;
  .handle {
    flex: 2;
    // height: 50em;
    // background-color: lightblue;
    .searchName {
      width: 70%;
    }
    .menu {
      padding: 5% 10% 0 10%;
      h4 {
        margin: 0.2em;
        padding-bottom: 0.5em;
      }
      .stydentForm {
        .el-form-item__content {
          // margin: 0 !important;
          .el-input__suffix {
            right: 0 !important;
          }
          .el-input {
            width: 70%;
          }
        }
      }
    }
  }
  .formData {
    flex: 3;
    text-align: center;
    .el-table {
      text-align: center !important;
      float: right;
      // padding: 5%
      margin: 2%;
    }
    // background-color: lightpink;
  }
}
</style>