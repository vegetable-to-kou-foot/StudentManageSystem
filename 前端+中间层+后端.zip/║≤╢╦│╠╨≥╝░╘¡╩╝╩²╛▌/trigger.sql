USE sms;

DELIMITER $
CREATE TRIGGER student_to_dept_update
AFTER UPDATE ON student
FOR EACH ROW
BEGIN
UPDATE class C
SET C.`class_cap` = (
SELECT COUNT(S.`stu_id`)
FROM student S
GROUP BY S.`class_id`
HAVING S.`class_id`=C.`class_id`
);
UPDATE dept D
SET D.`dept_cap` = (
SELECT COUNT(S.`stu_id`)
FROM student S
GROUP BY S.`dept_name`
HAVING S.`dept_name` = D.`dept_name`
);
END$
DELIMITER ;

DELIMITER $
CREATE TRIGGER student_to_dept_insert
AFTER INSERT ON student
FOR EACH ROW
BEGIN
UPDATE class C
SET C.`class_cap` = (
SELECT COUNT(S.`stu_id`)
FROM student S
GROUP BY S.`class_id`
HAVING S.`class_id`=C.`class_id`
);
UPDATE dept D
SET D.`dept_cap` = (
SELECT COUNT(S.`stu_id`)
FROM student S
GROUP BY S.`dept_name`
HAVING S.`dept_name` = D.`dept_name`
);
END$
DELIMITER ;

DELIMITER $
CREATE TRIGGER student_to_dept_delete
AFTER DELETE ON student
FOR EACH ROW
BEGIN
UPDATE class C
SET C.`class_cap` = (
SELECT COUNT(S.`stu_id`)
FROM student S
GROUP BY S.`class_id`
HAVING S.`class_id`=C.`class_id`
);
UPDATE dept D
SET D.`dept_cap` = (
SELECT COUNT(S.`stu_id`)
FROM student S
GROUP BY S.`dept_name`
HAVING S.`dept_name` = D.`dept_name`
);
END$
DELIMITER ;

SHOW TRIGGERS;