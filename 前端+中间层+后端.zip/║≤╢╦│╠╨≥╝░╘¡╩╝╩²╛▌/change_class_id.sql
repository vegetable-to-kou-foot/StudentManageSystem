SET GLOBAL log_bin_trust_function_creators=TRUE;
-- 函数创建失败，百度到的解决方法
DELIMITER $
CREATE FUNCTION change_class_id(old_id CHAR(10),new_id CHAR(10)) RETURNS INT
BEGIN
	DECLARE stu_num INT;
	UPDATE class SET class_id = new_id WHERE class_id = old_id;
	-- 创建student时已经和class指定了update cascade和delete cascade，因此不写update student...
	SELECT COUNT(stu_id) INTO stu_num FROM student WHERE class_id = new_id;
	RETURN stu_num;
END $
DELIMITER ;