DELIMITER $
CREATE PROCEDURE check_dept_cap()
BEGIN
DECLARE	dept_id INT;
DECLARE	dept_name VARCHAR(20);
DECLARE	dept_cap INT;
DECLARE	stu_num INT;
DECLARE mycur CURSOR FOR
		SELECT dept.`dept_id`,student.`dept_name`,dept.`dept_cap`,COUNT(stu_id)
		FROM student,dept
		WHERE 	student.`dept_name` = dept.`dept_name`
			AND student.`dept_name` = dept_name;
	
TRUNCATE TABLE temp;

	SET dept_name = '通信工程系';
	OPEN mycur;
	FETCH mycur INTO dept_id,dept_name,dept_cap,stu_num;
	IF dept_cap != stu_num THEN
		UPDATE dept SET dept.`dept_cap` = stu_num WHERE dept.`dept_name` = dept_name;
		INSERT INTO temp VALUES (dept_id,dept_name,dept_cap,stu_num);
	END IF;
	CLOSE mycur;
	
	SET dept_name = '电子工程系';
	OPEN mycur;
	FETCH mycur INTO dept_id,dept_name,dept_cap,stu_num;
	IF dept_cap != stu_num THEN
		UPDATE dept SET dept.`dept_cap` = stu_num WHERE dept.`dept_name` = dept_name;
		INSERT INTO temp VALUES (dept_id,dept_name,dept_cap,stu_num);
	END IF;
	CLOSE mycur;
	
	SET dept_name = '计算机系';
	OPEN mycur;
	FETCH mycur INTO dept_id,dept_name,dept_cap,stu_num;
	IF dept_cap != stu_num THEN
		UPDATE dept SET dept.`dept_cap` = stu_num WHERE dept.`dept_name` = dept_name;
		INSERT INTO temp VALUES (dept_id,dept_name,dept_cap,stu_num);
	END IF;
	CLOSE mycur;

END $
DELIMITER ;
	