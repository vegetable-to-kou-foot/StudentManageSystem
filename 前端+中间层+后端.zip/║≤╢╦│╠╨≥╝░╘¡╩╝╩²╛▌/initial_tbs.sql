CREATE DATABASE sms;
USE sms;
CREATE TABLE dept(
dept_id INT PRIMARY KEY,
dept_name VARCHAR(20) UNIQUE NOT NULL,
dept_office VARCHAR(20),
dept_cap INT
);
CREATE TABLE academy(
acad_id INT PRIMARY KEY,
acad_name VARCHAR(20) UNIQUE NOT NULL,
acad_year INT,
acad_pos VARCHAR(20)
);
CREATE TABLE dormitory(
dorm_id INT PRIMARY KEY,
dorm_cap INT
);

CREATE TABLE class(
class_id CHAR(10) NOT NULL,
major_name VARCHAR(20) NOT NULL,
class_year INT,
dept_name VARCHAR(20) NOT NULL,
class_cap INT,
PRIMARY KEY (class_id,major_name),
FOREIGN KEY(dept_name) REFERENCES dept(dept_name)
);
CREATE TABLE dept_dorm(
dept_id INT PRIMARY KEY,
dorm_id INT,
FOREIGN KEY(dorm_id) REFERENCES dormitory(dorm_id),
FOREIGN KEY(dept_id) REFERENCES dept(dept_id)
	ON UPDATE CASCADE
);
CREATE TABLE student(
stu_id	CHAR(15) PRIMARY KEY,
stu_name CHAR(10) NOT NULL,
stu_sex	CHAR(5) NOT NULL,
stu_age INT,
dept_name VARCHAR(20),
class_id CHAR(10),
dorm_id INT,
FOREIGN KEY(dept_name) REFERENCES dept(dept_name),
FOREIGN KEY(class_id) REFERENCES class(class_id)
	ON UPDATE CASCADE
	ON DELETE CASCADE,
FOREIGN KEY(dorm_id) REFERENCES dormitory(dorm_id),
CHECK (stu_sex IN ('女','男'))
);
CREATE TABLE stu_acad(
stu_id CHAR(15),
acad_id INT,
FOREIGN KEY(stu_id) REFERENCES student(stu_id)
	ON DELETE CASCADE,
FOREIGN KEY(acad_id) REFERENCES academy(acad_id)
	ON DELETE CASCADE,
join_year INT,
PRIMARY KEY (stu_id,acad_id)
);
CREATE TABLE temp(
dept_id INT PRIMARY KEY,
dept_name VARCHAR(20) UNIQUE NOT NULL,
dept_cap INT,
stu_num INT
);