package classs;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.Classs;
import mapper.ClasssMapper;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class GetClasss extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request,response);
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");
        String resource = "mybatis/mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //下面这个函数参数最好用true，虽然会降低性能但是能及时写入数据库。
        SqlSession sqlSession = sqlSessionFactory.openSession(true);

        ClasssMapper classsMapper = sqlSession.getMapper(ClasssMapper.class);
        List<Classs> classsList = classsMapper.getClasss();

        System.out.println(classsList.get(0).toString());

        PrintWriter out = response.getWriter();
        out.write("[");
        for (int i=0;i<classsList.size();i++){
            out.write(classsList.get(i).toString());
            if (i != classsList.size()-1){
                out.write(",");
            }else{
                out.write("]");
            }
        }
        out.close();

        sqlSession.commit();
        sqlSession.close();
        return;
    }
}