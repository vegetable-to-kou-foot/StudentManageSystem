package classs;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mapper.ClasssMapper;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class ChangeClasssId extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request,response);
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");
        String old_class_id = request.getParameter("old_class_id");
        String new_class_id = request.getParameter("new_class_id");

        String resource = "mybatis/mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //下面这个函数参数最好用true，虽然会降低性能但是能及时写入数据库。
        SqlSession sqlSession = sqlSessionFactory.openSession(true);

        ClasssMapper classsMapper = sqlSession.getMapper(ClasssMapper.class);
        int class_cap = classsMapper.changeClassId(old_class_id,new_class_id);

        PrintWriter out = response.getWriter();
        out.write(String.format("{\"class_cap\":\"%s\"}",class_cap));
        out.close();

        sqlSession.commit();
        sqlSession.close();
        return;
    }
}