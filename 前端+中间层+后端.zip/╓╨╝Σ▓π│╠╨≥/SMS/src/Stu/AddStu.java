package Stu;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.Stu;
import mapper.StuMapper;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.reflection.SystemMetaObject;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class AddStu extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request,response);
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");
        String stu_id = request.getParameter("stu_id");
        String stu_name = request.getParameter("stu_name");
        String stu_sex = request.getParameter("stu_sex");
        int stu_age = Integer.parseInt(request.getParameter("stu_age"));
        String dept_name = request.getParameter("dept_name");
        String class_id = request.getParameter("class_id");
        int dorm_id = Integer.parseInt(request.getParameter("dorm_id"));
        System.out.println(stu_id);
        System.out.println(stu_name);
        String resource = "mybatis/mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        StuMapper stuMapper = sqlSession.getMapper(StuMapper.class);

        Stu ss = new Stu();
        ss.setAll(stu_id,stu_name,stu_sex,stu_age,dept_name,class_id,dorm_id);

        System.out.println(ss.toString());
        System.out.println(ss.getStuAge());
        stuMapper.addStu(ss);

        /*
        System.out.println(ss.getStuName());
        sqlSession.insert("mapper.userMapper.addStu", ss);*/

        sqlSession.commit();
        sqlSession.close();
        return;
    }
}