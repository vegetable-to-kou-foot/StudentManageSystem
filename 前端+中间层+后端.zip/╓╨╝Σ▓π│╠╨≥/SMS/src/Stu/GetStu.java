package Stu;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.Acad;
import entity.Stu;
import mapper.AcadMapper;
import mapper.StuMapper;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class GetStu extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request,response);
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");
        String resource = "mybatis/mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //下面这个函数参数最好用true，虽然会降低性能但是能及时写入数据库。
        SqlSession sqlSession = sqlSessionFactory.openSession(true);

        StuMapper stuMapper = sqlSession.getMapper(StuMapper.class);
        AcadMapper acadMapper = sqlSession.getMapper(AcadMapper.class);
        List<Stu> stuList = stuMapper.getStu();

        PrintWriter out = response.getWriter();
        out.write("[");
        for (int i=0;i<stuList.size();i++){

            List<Acad> acadList = acadMapper.findAcad(stuList.get(i).getStuId());
            String allAcad = "[";
            for (int j=0;j<acadList.size();j++){
                allAcad += acadList.get(j).toString2();
                if (j != acadList.size()-1) allAcad += ",";
            }
            allAcad += "]";

            out.write(stuList.get(i).toString2(allAcad));
            if (i != stuList.size()-1){
                out.write(",");
            }else{
                out.write("]");
            }
        }
        out.close();

        sqlSession.commit();
        sqlSession.close();
        return;
    }

    /*private List<Stu> find() throws IOException {
        String resource = "mybatis/mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        List<Stu> stuList = sqlSession.selectList("mapper.userMapper.getStu");
        sqlSession.close();
        return stuList;
    }*/
}