package entity;

import java.net.Inet4Address;
import java.util.HashMap;
import java.util.Map;

public class Dept {
    private int deptId;
    private String deptName;
    private String deptOffice;
    private int deptCap;

    public int getDeptId() {
        return deptId;
    }

    public void setDeptId(int deptId) {
        this.deptId = deptId;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getDeptOffice() {
        return deptOffice;
    }

    public void setDeptOffice(String deptOffice) {
        this.deptOffice = deptOffice;
    }

    public int getDeptCap() {
        return deptCap;
    }

    public void setDeptCap(int deptCap) {
        this.deptCap = deptCap;
    }

    @Override
    public String toString() {
        return String.format("{\"dept_id\":\"%s\",\"dept_name\":\"%s\",\"dept_office\":\"%s\"" +
                        ",\"dept_cap\":\"%s\"}",
                deptId,deptName,deptOffice,deptCap);
    }

}
