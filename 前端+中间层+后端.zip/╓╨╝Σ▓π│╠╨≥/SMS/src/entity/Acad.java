package entity;

public class Acad {
    private int acadId;
    private int joinYear;
    private String acadName;
    private int acadYear;
    private String acadPos;
    private int acadCap;

    public int getAcadId() {
        return acadId;
    }

    public void setAcadId(int acadId) { this.acadId = acadId; }
    public int getJoinYear() {
        return joinYear;
    }
    public void setJoinYear(int joinYear) {
        this.joinYear = joinYear;
    }
    public String getAcadName() { return acadName; }

    public void setAcadName(String acadName) {
        this.acadName = acadName;
    }
    public int getAcadYear() {
        return acadYear;
    }
    public void setAcadYear(int acadYear) {
        this.acadYear = acadYear;
    }
    public String getAcadPos() {
        return acadPos;
    }
    public void setAcadPos(String acadPos) {
        this.acadPos = acadPos;
    }
    public int getAcadCap() {
        return acadCap;
    }
    public void setAcadCap(String acadCap) {
        this.acadCap = Integer.parseInt(acadCap);
    }


    @Override
    public String toString() {
        return String.format("{\"acad_name\":\"%s\",\"acad_cap\":\"%s\"}",
                acadName,acadCap);
    }

    public String toString2() {
        return String.format("{\"acad_id\":\"%s\",\"join_year\":\"%s\",\"acad_name\":\"%s\",\"acad_year\":\"%s\",\"acad_pos\":\"%s\"}",
                acadId,joinYear,acadName,acadYear,acadPos);
    }

    public String toString3(String allStu) {
        return String.format("{\"acad_id\":\"%s\",\"acad_name\":\"%s\",\"acad_year\":\"%s\",\"acad_pos\":\"%s\"" +
                        ",\"acad_cap\":\"%s\",\"stu\":%s}",
                acadId,acadName,acadYear,acadPos,acadCap,allStu);
    }
}
