package entity;

import java.util.HashMap;
import java.util.Map;

public class Stu {
    private String stuId;
    private String stuName;
    private String stuSex;
    private int stuAge;
    private String deptName;
    private String classId;
    private int dormId;
    private int joinYear;
    public int getJoinYear() {
        return joinYear;
    }

    public void setJoinYear(int joinYear) {
        this.joinYear = joinYear;
    }


    public String getStuId() {
        return stuId;
    }
    public void setStuId(String stuId) {
        this.stuId = stuId;
    }
    public String getStuName() { return stuName; }
    public void setStuName(String stuName) {
        this.stuName = stuName;
    }
    public String getStuSex() {
        return stuSex;
    }
    public void setStuSex(String stuSex) {
        this.stuSex = stuSex;
    }
    public int getStuAge() {
        return stuAge;
    }
    public void setStuAge(int stuAge) {
        this.stuAge = stuAge;
    }
    public String getDeptName() {
        return deptName;
    }
    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }
    public String getClassId() {
        return classId;
    }
    public void setClassId(String classId) {
        this.classId = classId;
    }
    public int getDormId() {
        return dormId;
    }
    public void setDormId(int dormId) {
        this.dormId = dormId;
    }
    public void setAll(String stuId,String stuName,String stuSex,int stuAge,String deptName,String classId,int dormId){
        setStuId(stuId);
        setStuName(stuName);
        setStuSex(stuSex);
        setStuAge(stuAge);
        setDeptName(deptName);
        setClassId(classId);
        setDormId(dormId);
    }

    public static Map<String, Object> setStuMap(String stuId, String stuName, String stuSex, int stuAge, String deptName, String classId, int dormId){
        Map<String,Object> params = new HashMap<>();
        params.put("stuId", stuId);
        params.put("stuName", stuName);
        params.put("stuSex", stuSex);
        params.put("stuAge", stuAge);
        params.put("deptName", deptName);
        params.put("classId", classId);
        params.put("dormId", dormId);
        return params;
    }

    @Override
    public String toString() {
        return String.format("{\"stu_id\":\"%s\",\"stu_name\":\"%s\",\"stu_sex\":\"%s\"" +
                        ",\"stu_age\":\"%s\",\"dept_name\":\"%s\",\"class_id\":\"%s\",\"dorm_id\":\"%s\"}",
                stuId,stuName,stuSex,stuAge,deptName,classId,dormId);
    }

    public String toString2(String allAcad) {
        return String.format("{\"stu_id\":\"%s\",\"stu_name\":\"%s\",\"stu_sex\":\"%s\"" +
                        ",\"stu_age\":\"%s\",\"dept_name\":\"%s\",\"class_id\":\"%s\",\"dorm_id\":\"%s\",\"acad\":%s}",
                stuId,stuName,stuSex,stuAge,deptName,classId,dormId,allAcad);
    }

    public String toString3() {
        return String.format("{\"stu_id\":\"%s\",\"stu_name\":\"%s\",\"join_year\":\"%s\"}",
                stuId,stuName,joinYear);
    }
}
