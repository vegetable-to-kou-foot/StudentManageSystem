package entity;

import java.net.Inet4Address;
import java.util.HashMap;
import java.util.Map;

public class ChangedDept {
    private int deptId;
    private String deptName;
    private int deptCap;
    private int stuNum;

    public int getDeptId() {
        return deptId;
    }

    public void setDeptId(int deptId) {
        this.deptId = deptId;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public int getDeptCap() {
        return deptCap;
    }

    public void setDeptCap(int deptCap) {
        this.deptCap = deptCap;
    }

    public int getStuNum() {
        return stuNum;
    }

    public void setStuNum(int stuNum) {
        this.stuNum = stuNum;
    }

    @Override
    public String toString() {
        return String.format("{\"dept_id\":\"%s\",\"dept_name\":\"%s\"" +
                        ",\"dept_cap\":\"%s\",\"stu_num\":\"%s\"}",
                deptId,deptName,deptCap,stuNum);
    }

}
