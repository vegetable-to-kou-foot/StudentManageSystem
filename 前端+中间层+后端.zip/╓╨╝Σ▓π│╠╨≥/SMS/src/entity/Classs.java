package entity;

import java.net.Inet4Address;
import java.util.HashMap;
import java.util.Map;

public class Classs {
    private String classId;
    private String majorName;
    private int classYear;
    private String deptName;
    private int classCap;

    public String getClassId() {
        return classId;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    public String getMajorName() {
        return majorName;
    }

    public void setMajorName(String majorName) {
        this.majorName = majorName;
    }

    public int getClassYear() {
        return classYear;
    }

    public void setClassYear(String classYear) {
        this.classYear = Integer.parseInt(classYear);
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public int getClassCap() {
        return classCap;
    }

    public void setClassCap(String classCap) {
        this.classCap = Integer.parseInt(classCap);
    }

    @Override
    public String toString() {
        return String.format("{\"class_id\":\"%s\",\"major_name\":\"%s\",\"class_year\":\"%s\"" +
                        ",\"dept_name\":\"%s\",\"class_cap\":\"%s\"}",
                classId,majorName,classYear,deptName,classCap);
    }

}
