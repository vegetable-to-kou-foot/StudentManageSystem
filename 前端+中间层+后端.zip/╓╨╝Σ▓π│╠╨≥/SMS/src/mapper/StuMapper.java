package mapper;

import java.util.List;

import org.apache.ibatis.annotations.*;

import entity.Stu;

public interface StuMapper {

    @Insert(" insert into student  values (${stu.stuId},${stu.stuName},${stu.stuSex},${stu.stuAge},${stu.deptName},${stu.classId},${stu.dormId}) ")
    public void addStu(@Param("stu") Stu stu);

    @Delete(" delete from student where student.stu_id = ${stuId} ")
    public void delStu(@Param("stuId") String stuId);

    /*@Select("select * from category_ where id= #{id} ")
    public Stu getStu();*/

    /*@Update("update category_ set name=#{name} where id=#{id} ")
    public void update(Stu stu);*/

    @Select(" select * from student")
    public List<Stu> getStu();

    @Select(" select A.stu_id stu_id,A.stu_name stu_name,B.join_year join_year " +
            "from student A,stu_acad B " +
            "where A.stu_id=B.stu_id and B.acad_id = ${acadId}")
    public List<Stu> findStu(@Param("acadId") int acadId);
}