package mapper;

import java.util.List;

import org.apache.ibatis.annotations.*;

import entity.Classs ;
import org.apache.ibatis.mapping.StatementType;

public interface ClasssMapper {

    @Select("select change_class_id(${oldClasssId},${newClasssId})")
    @Options(statementType= StatementType.CALLABLE)
    public int changeClassId(@Param("oldClasssId") String oldClasssId,@Param("newClasssId") String newClasssId);

    @Select(" select * from class")
    public List<Classs> getClasss();
}