package mapper;

import java.util.List;

import org.apache.ibatis.annotations.*;

import entity.Acad;

public interface AcadMapper {

    @Select("create view acad as " +
            "select acad_name,count(stu_id) acad_cap " +
            "from academy A,stu_acad B " +
            "where A.acad_id=B.acad_id " +
            "group by acad_name")
    public void createAcad();

    @Select("select A.acad_id,B.join_year,A.acad_name,A.acad_year,A.acad_pos " +
            "from academy A,stu_acad B " +
            "where B.stu_id = ${stuId} and A.acad_id = B.acad_id")
    public List<Acad> findAcad(@Param("stuId") String stuId);

    @Select("select A.acad_id acad_id,A.acad_name acad_name,A.acad_year acad_year,A.acad_pos acad_pos,B.acad_cap acad_cap " +
            "from academy A,acad B " +
            "where A.acad_name=B.acad_name")
    public List<Acad> getAcad();

    @Delete("drop view if exists acad")
    public void delAcad();

    @Insert("insert into stu_acad values (${stuId},${acadId},${joinYear})")
    public void joinAcad(@Param("stuId") String stuId,@Param("acadId") int acadId,@Param("joinYear") int joinYear);

    @Delete("delete from stu_acad where stu_id = ${stuId} and acad_id = ${acadId}")
    public void quitAcad(@Param("stuId") String stuId,@Param("acadId") int acadId);
}