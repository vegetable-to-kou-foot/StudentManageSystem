package mapper;

import java.util.List;

import entity.ChangedDept;
import entity.Dept;
import org.apache.ibatis.annotations.*;

import entity.Classs ;
import org.apache.ibatis.mapping.StatementType;

public interface DeptMapper {

    @Select("call check_dept_cap")
    @Options(statementType= StatementType.CALLABLE)
    public void callDeptCapChecker();

    @Select("select * from temp")
    public List<ChangedDept> getChangedDept();

    @Select(" select * from dept")
    public List<Dept> getDept();
}