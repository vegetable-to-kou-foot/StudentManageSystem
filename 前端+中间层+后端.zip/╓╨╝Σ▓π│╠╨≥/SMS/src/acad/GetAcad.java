package acad;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.Acad;
import entity.Stu;
import mapper.AcadMapper;
import mapper.StuMapper;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class GetAcad extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request,response);
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");
        String resource = "mybatis/mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        //下面这个函数参数最好用true，虽然会降低性能但是能及时写入数据库。
        SqlSession sqlSession = sqlSessionFactory.openSession(true);

        StuMapper stuMapper = sqlSession.getMapper(StuMapper.class);
        AcadMapper acadMapper = sqlSession.getMapper(AcadMapper.class);
        acadMapper.delAcad();
        acadMapper.createAcad();
        List<Acad> acadList = acadMapper.getAcad();

        PrintWriter out = response.getWriter();
        out.write("[");
        for (int i=0;i<acadList.size();i++){

            List<Stu> stuList = stuMapper.findStu(acadList.get(i).getAcadId());
            String allStu = "[";
            for (int j=0;j<stuList.size();j++){
                allStu += stuList.get(j).toString3();
                if (j != stuList.size()-1) allStu += ",";
            }
            allStu += "]";

            out.write(acadList.get(i).toString3(allStu));
            if (i != acadList.size()-1){
                out.write(",");
            }else{
                out.write("]");
            }
        }
        out.close();

        sqlSession.commit();
        sqlSession.close();
        return;
    }
}